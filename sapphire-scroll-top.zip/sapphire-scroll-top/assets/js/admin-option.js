(function($){
    'user strict'

    $(document).ready(function () {
        // Add Color Picker.
        $('#sphr_st_icon_color, #sphr_st_icon_bg_color').wpColorPicker();
    });
    
})(jQuery);