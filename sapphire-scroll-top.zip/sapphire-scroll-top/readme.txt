=== Sapphire Scroll Top ===
Contributors: sapphireit, bayejid00
Tags: scroll to top, scroll top, wordpress scroll top, back to top, scroll up, sapphire scroll to top
Requires at least: 5.0
Tested up to: 6.3
Requires PHP: 5.3
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.txt

Sapphire Scroll Top plugin allows the visitor to easily scroll back to the top of the page or posts.

== Description ==
Sapphire Scroll Top plugin allows the visitor to easily scroll back to the top of the page or posts, with fully customizable options. Sapphire Scroll Top plugin has the following features.

### Features
* Small size for fast loading website.
* Front color Selection.
* Background color selection.
* Light weight.
* Async JavaScript.


== Installation ==

1. Click Plugins/Add New from the WordPress admin panel.
1. Search for "Sapphire Scroll Top" and install.

-or-

1. Download the .zip package.
1. Unzip into the subdirectory 'sapphire-scroll-top' within your local WordPress plugins directory.
1. Refresh plugin page and activate plugin.
1. Configure plugin using *Sapphire Scroll Top* link under 'Settings' menu.

== Frequently Asked Questions ==
 

== Screenshots ==

1. Settings page. 

